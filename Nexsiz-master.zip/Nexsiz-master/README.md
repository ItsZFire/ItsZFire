# Nexsiz

[![Discord Bot](https://img.shields.io/badge/DiscordBot-Yes-green.svg)](https://discordapp.com/api/oauth2/authorize?client_id=552076002101297153&permissions=8&scope=bot)
[![HitCount](http://hits.dwyl.com/PritePasZ/Nexsiz.svg)](http://hits.dwyl.com/PritePasZ/Nexsiz)

**Made By PritePasZ**

* **Version 0.1.7b**

For educational purposes.

Credits : To TheSourceCode for their useful guides & tutorial on how to javascript the bot

---

# What is Nexsiz

Nexsiz is Discord Bot with alot of Fun commands and General Commands

Host bot for 24/7
By Heroku

### -- Notice --

* We're still adding the commands, stuff and more features

* And trying to fixed some bug

### Using the Official Nexsiz Bot

[Click here to invite Nexsiz in to your server!](https://discordapp.com/oauth2/authorize?client_id=552076002101297153&scope=bot&permissions=2146954495)

---

# Support
* `n!help` - To view all of the commands (bot will message in to your direct message)

* If you have any questions feel free to **Join The Discord Server**

* Would like to suggest features, join my bot development server here:  [Support Server & Coding (Alpha)](https://discord.gg/TPTDyPd)

* Found bug? Use `n!contact` to let us know!

I am open to feedback and suggestions. Feel free to submit a pull request or open an issue :)

---
